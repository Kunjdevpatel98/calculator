let display = '';
document.querySelector('#box').value = display;